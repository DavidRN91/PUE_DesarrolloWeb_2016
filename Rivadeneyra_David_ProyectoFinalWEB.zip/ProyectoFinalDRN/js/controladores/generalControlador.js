//<!--Welcome to my page -->
//<!--JAVASCRIPT controlador general-->
//<!--David Rivadeneyra Núñez -->

// variable de localhost, cambiarlodependiendo de la carpeta,
//localhost:8000 abrirlo con puerto servidor.py
var localhost = "http://localhost:8000/Desktop/ProyectoFinalDRN/";
//funcion CTRL
var Ctrl = (function(){

//buscador, controlador y llamada al json
	var _buscadorCtrl = function($scope,$http,$log,$window){
		$http.get(localhost+"json/todocomics/TODOCOMICS.json")
			.success(function(respComics){
				$scope.comics = respComics;
				//$log.log("USUARIOS:")
				//$log.log(JSON.stringify($scope.usuarios))
			})
			.error(function(err){
				$log.log("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
				$window.alert("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
			})
			$scope.mostrarTabla=true;
	};
// Editar con etiquetas el mouseover sobre objetos para cambiarlos desde el css
//barra menu, controlador
	var _barraNavController = function(){
			angular.element("nav>div>div>ul>li").on("mouseover", function(){
				angular.element(this).addClass("fundidoNaranja");
			})
			angular.element("nav>div>div>ul>li").on("mouseleave", function(){
				angular.element(this).removeClass("fundidoNaranja");
			})
			
			angular.element("nav>div>div>ul>li").on("click", function(){
				angular.element("nav>div>div>ul>li").removeClass("active");
				angular.element(this).addClass("active");
			})
		}
//	//por cada titulo, un controlador y llamada al json
	var _nombreTituloCtrl = function($scope,$http,$log,$window,$routeParams){
		//comprobar titulo
		$scope.porid = {}
		$scope.porid.idcomic = $routeParams.comic
		
		$http.get(localhost+"json/todocomics/TODOCOMICS.json")
			.success(function(respComics){
				$scope.comics = respComics;
				//$log.log("USUARIOS:")
				//$log.log(JSON.stringify($scope.usuarios))
			})
			.error(function(err){
				$log.log("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
				$window.alert("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
			})
	}

// por cada genero un controlador y llamada al json
	var _GeneroCtrl = function($scope,$http,$log){
		//Por genero titulo
		$scope.generoElegido = function (e){
 			//$log.log("está funcionando")
			//$log.log('http://localhost:8000/Desktop/ProyectoFinalDRN/json/porgeneros/'+e+".json")
			$http.get(localhost+"json/porgeneros/"+e+".json")
			.success(function(respComics){
				$log.log(respComics)
				$scope.comics = respComics;
				//$log.log("USUARIOS:")
				//$log.log(JSON.stringify($scope.usuarios))
			})
			.error(function(err){
				$log.log("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
				$window.alert("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
			})
	}
}
//al hacer click en boton de la vista studio, controlador y llamada al json
	var _nombreStudioCtrl = function($scope,$http,$log,$window,$routeParams){
		//comprobar titulo
		$scope.studioElegido = function (s){
 			//$log.log($scope.studio)
			
			//$log.log('http://localhost:8000/Desktop/ProyectoFinalDRN/json/porstudios/'+e+".json")
			$http.get(localhost+"json/porstudios/" + s + ".json")
			.success(function(respComics){
				$log.log(respComics)
				$scope.comics = respComics;
				//$log.log("USUARIOS:")
				//$log.log(JSON.stringify($scope.usuarios))
			})
			.error(function(err){
				$log.log("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
				$window.alert("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
			})
	}
}

//al hacer click en boton de la vista superheroes, controlador y llamada al json
	var _nombreHeroeCtrl = function($scope,$http,$log,$window,$routeParams){
		//comprobar titulo
		$scope.heroeElegido = function (h){
		$http.get(localhost+"json/porheroes/" + h + '.json')
			.success(function(respComics){
				$log.log(respComics)
				$scope.comics = respComics;
				//$log.log("USUARIOS:")
				//$log.log(JSON.stringify($scope.usuarios))
			})
			.error(function(err){
				$log.log("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
				$window.alert("Fallo en la peticion AJAX " + err.code + " -- " + err.message)
			})
	}
}
// Devuelve un controlador de forma variable, con valores:
return {
		buscadorCtrl: _buscadorCtrl,
		barraNavController:_barraNavController,
		nombreTituloCtrl:_nombreTituloCtrl,
		GeneroCtrl:_GeneroCtrl,
		nombreStudioCtrl:_nombreStudioCtrl,
		nombreHeroeCtrl:_nombreHeroeCtrl

	}
})();