
// impotar paquetes de node creados por terceros
// para tener disponibles las funciones que crean los servidores
var webSocket = require('websocket').server;
var http = require('http');

// crear y levantar un servidor WEB 
// con acceso a "to la banda" 
// en el puerto 8080 
var servidorHttp = http.createServer(function(){
}).listen(8080);

// crear servidor websocket 
// para poder IDENTIFICAR a clientes
// sobre el servidor web
var servidorWebSocket = new webSocket({
	httpServer: servidorHttp
})

var clientes = [];

servidorWebSocket.on('request',function(request){
	// acepto peticion de conexion del cliente
	// y lo alamaceno en el array
	var cliente = request.accept();
	console.log(cliente)
	clientes.push(cliente);

	// Que hago cuando un cliente YA CONECTADO me manda info!!
	cliente.on('message', function(mensaje){
		if ( mensaje.type == 'utf8' ){
			for (pos in clientes){
				clientes[pos].sendUTF("Hola "+ mensaje.utf8Data);
			}
		}
	})
})