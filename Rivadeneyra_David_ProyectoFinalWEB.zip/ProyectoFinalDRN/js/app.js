//<!--Welcome to my page -->
//<!-- JAVASCRIPT app-->
//<!--David Rivadeneyra Núñez -->

//RUTAS
var vistaRutasMod = angular.module('miApp',['ngRoute']);
		vistaRutasMod.config(['$routeProvider',function($routeProvider){
			$routeProvider.
			when("/",{
				templateUrl: "vistas/inicio.html"
			}).
			when("/buscar",{
				templateUrl: "vistas/buscador.html",
				controller: Ctrl.buscadorCtrl
			}).
			when("/filtrar",{
				templateUrl: "vistas/generos.html",
				controller: Ctrl.GeneroCtrl
			}).
			when("/info",{
				templateUrl: "vistas/alumno.html"
				//controller: Ctrl.alumnoCtrl
			}).
			when("/heroes",{
				templateUrl: "vistas/superheroes.html",
				controller: Ctrl.nombreHeroeCtrl
			}).
			when("/colecciones",{
				templateUrl: "vistas/studios.html",
				controller: Ctrl.nombreStudioCtrl
			}).
			when("/contacto",{
				templateUrl: "vistas/contactar.html"
				//controller: Ctrl.contactarCtrl
			}).
			when("/eoi",{
				templateUrl: "vistas/pue.html"
				//controller: Ctrl.pueCtrl
			}).
			when("/menu0",{
				templateUrl: "vistas/menu0.html"
				
			}).
			when("/menu1",{
				templateUrl: "vistas/menu1.html"
				
			}).
			when("/menu2",{
				templateUrl: "vistas/menu2.html"
				
			}).
			when("/menu3",{
				templateUrl: "vistas/menu3.html"
				
			}).
			
			when("/comic/:comic",{
				templateUrl: "vistas/nombreTitulo.html",
				controller: Ctrl.nombreTituloCtrl
			}).

			// en caso de no estar en ninguna vista
			otherwise({redirectTo: '/'})
		}]);

		vistaRutasMod.directive("barraNav",function(){
//devuelve con valor la vista de barra menu deforma fija
			return {	restrict: "E",
			templateUrl:"vistas/barramenu.html",
			controller: Ctrl.barraNavController
			}
		})

